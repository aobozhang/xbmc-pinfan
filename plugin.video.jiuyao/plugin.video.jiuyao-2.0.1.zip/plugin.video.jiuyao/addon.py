# -*- coding: utf-8 -*-
# Module: default
# Author: AoboZhang
# Created on: 06.08.2020
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
# Largely following the example at
# https://github.com/romanvm/plugin.video.example/blob/master/main.py
from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
import sys
import os
import urllib
import urllib2
from urlparse import parse_qsl
import simplejson as json
import random
import logging
import requests


def post(url, config, data=None, auth=False, retry=0):
    thisHeaders = headers
    if auth:
        thisHeaders['Authorization'] = 'Bearer {0}'.format(config['token'])

    r = requests.post(url, data=data, headers=thisHeaders)

    if r.status_code == 200:
        return r
    if auth and r.status_code >= 400:
        doLogin(config)

    retry += 1
    if retry < 3:
        return post(url, config, data, auth, retry)
    else:
        dialog.ok('Error', 'Request Error {0}'.format(r.status_code))


def get(url, config, auth=False, retry=0):
    thisHeaders = headers
    if auth:
        thisHeaders['Authorization'] = 'Bearer {0}'.format(config['token'])

    r = requests.get(url, headers=thisHeaders)

    if r.status_code == 200:
        return r
    if r.status_code >= 400:
        doLogin(config)

    retry += 1
    if retry < 3:
        return get(url, config, auth=auth, retry=retry)
    else:
        dialog.ok('Error', 'Request Error {0}'.format(r.status_code))


# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])
__addonname__ = "酒药"
__addonid__ = "plugin.video.jiuyao"
# _base = "http://lara-spider.test"
_base = "https://s1.aoboz.xyz"
_apitoken = '{0}{1}'.format(_base, "/api/token")
_apilist = '{0}{1}'.format(_base, "/api/kodi")

__addon__ = xbmcaddon.Addon(id=__addonid__)
__addonicon__ = os.path.join(__addon__.getAddonInfo('path'), 'icon.png')

dialog = xbmcgui.Dialog()
pDialog = xbmcgui.DialogProgressBG()
config = {}
headers = {
    "Accept": "application/json",
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36'
}


def index(config):
    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.setPluginCategory(_handle, '目录')
    list_from_source('目录', _apilist, config, False)


def list_from_source(label, source, config, home=True):
    lists = []
    name = label
    res = get(source, config, auth=True)
    if not res:
        return
    items = res.json()

    if home:
        home_list(lists)

    if items.has_key('links'):
        links = items['links']
        deal_links(label, links, lists)

    if items.has_key('meta'):
        meta = items['meta']
        if meta.has_key('current_page'):
            name = '{0} - 第 {1} 页'.format(label, meta['current_page'])

    if items.has_key('data'):
        data = items['data']
        xbmcplugin.setContent(_handle, 'videos')
        deal_data(data, lists)

    xbmcplugin.setPluginCategory(_handle, name)
    xbmcplugin.addDirectoryItems(_handle, lists, len(lists))
    xbmcplugin.endOfDirectory(_handle)


def home_list(lists):
    list_item = xbmcgui.ListItem(label='目录')
    is_folder = True
    parameters = {
        "action": 'home',
        "label": '目录',
        "source": _apilist
    }
    url = '{0}?{1}'.format(_url, urllib.urlencode(parameters))
    lists.append((url, list_item, is_folder))
    return


def deal_links(label, links, lists):
    for key in links:
        link = links[key]
        key = key.encode('utf-8')
        if key == 'first':
            key = '首页'
        elif key == 'last':
            key = '末页'
        elif key == 'prev':
            key = '上一页'
        elif key == 'next':
            key = '下一页'
        else:
            label = key

        if link:
            list_item = xbmcgui.ListItem(label=key)
            is_folder = True
            parameters = {
                "action": 'listing',
                "label": label,
                "source": link
            }
            url = '{0}?{1}'.format(_url, urllib.urlencode(parameters))
            lists.append((url, list_item, is_folder))
        else:
            pass
    return


def deal_data(data, lists):
    is_folder = False
    for item in data:
        parameters = {
            "action": 'play',
            "video": json.dumps(item)
        }
        url = '{0}?{1}'.format(_url, urllib.urlencode(parameters))
        lists.append((url, deal_vdo(item), is_folder))

    return


def deal_vdo(item):
    list_item = xbmcgui.ListItem(label=item['label'], path=item['path'])
    list_item.setProperty('IsPlayable', 'true')
    for key in item:
        if key == 'info':
            info = item['info']
            for key in info:
                value = info[key]
                try:
                    list_item.setInfo(type='Video',
                                      infoLabels={key: value})
                except:
                    pass
        elif key == 'art':
            art = item['art']
            for key in art:
                value = art[key]
                try:
                    list_item.setArt({key: value})
                except:
                    pass
        elif key == 'streamInfo':
            streamInfo = item['streamInfo']
            for key in streamInfo:
                value = streamInfo[key]
                try:
                    list_item.setStreamInfo({key: value})
                except:
                    pass
        elif key == 'action':
            action = item['action']
            for key in action:
                value = action[key]
                try:
                    parameters = {
                        "action": 'action',
                        "url": value
                    }
                    act = 'RunScript({0}, {1}, ?{2})'.format(__addonid__,
                                                             _handle,
                                                             urllib.urlencode(parameters))
                    list_item.addContextMenuItems(
                        [(key.encode('utf-8'), act)])
                except Exception as e:
                    pass

    return list_item


def play_vdo(encodedVdo):
    item = json.loads(encodedVdo)
    play_item = deal_vdo(item)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    xbmc.sleep(200)


def dialog_open_settings():
    ret = dialog.yesno(heading='Information',
                       line1='Your need Config account before use this addon.',
                       line2='!RESTART! addon is needed after save settings',
                       nolabel='CANCEL',
                       yeslabel='SETTING',
                       autoclose=0)
    if ret:
        __addon__.openSettings()
    else:
        return False


def getConf(config):

    config['email'] = __addon__.getSetting('email').encode('utf-8')
    config['password'] = __addon__.getSetting('password').encode('utf-8')
    config['token'] = __addon__.getSetting('token')

    return checkConf(config)


def checkConf(config, checkToken=True):
    if not config['email'] or not config['password']:
        dialog_open_settings()
        return False
    elif checkToken and not config['token']:
        doLogin(config)
        return False
    else:
        return True


def doAction(url, config, auth=True):
    post(url, config, auth=True)


def doLogin(config):

    checkConf(config, checkToken=False)

    data = {
        "email": config['email'],
        "password": config['password'],
        "device_name": __addonid__
    }

    r = post(_apitoken, config=config, data=data, auth=False, retry=1)

    if not r:
        dialog_open_settings()
        return

    config['token'] = r.text
    __addon__.setSetting('token', r.text)
    xbmc.sleep(2000)

    index(config)


class SettingMonitor(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        getConf(config)


def router(paramstring, config):
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'home':
            # Display the list of videos in a provided category.
            list_from_source(params['label'], params['source'], config, False)
        elif params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_from_source(params['label'], params['source'], config)
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_vdo(params['video'])
        elif params['action'] == 'action':
            # Play a video from a provided URL.
            doAction(params['url'], config)
        elif params['action'] == 'login':
            # Play a video from a provided URL.
            doLogin(config)
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        index(config)


if __name__ == '__main__':
    if getConf(config):
        monsettings = SettingMonitor()
        router(sys.argv[2][1:], config)
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
